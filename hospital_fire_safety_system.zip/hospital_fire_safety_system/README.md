# نظام إدارة السلامة من الحرائق للمستشفى

هذا هو الكود المصدري لنظام إدارة السلامة من الحرائق للمستشفى. يمكنك استخدام هذا الكود لنشر النظام على استضافة دائمة.

## 🚀 كيفية النشر

يمكنك نشر هذا التطبيق على العديد من منصات الاستضافة. فيما يلي بعض الخيارات الشائعة:

### 1. النشر على Heroku (موصى به للمبتدئين)

Heroku هي منصة سحابية سهلة الاستخدام لنشر تطبيقات الويب.

**المتطلبات:**
- حساب Heroku (مجاني أو مدفوع)
- Heroku CLI (أداة سطر الأوامر لـ Heroku) مثبتة على جهازك.
- Git مثبت على جهازك.

**الخطوات:**
1.  **تسجيل الدخول إلى Heroku:**
    ```bash
    heroku login
    ```
2.  **إنشاء تطبيق Heroku جديد:**
    ```bash
    heroku create your-app-name-here # استبدل your-app-name-here باسم فريد لتطبيقك
    ```
3.  **إضافة ملفات المشروع إلى Git:**
    ```bash
    cd /path/to/your/project/folder # انتقل إلى مجلد المشروع الذي قمت بتحميله
    git init
    git add .
    git commit -m "Initial commit"
    ```
4.  **ربط مستودع Git الخاص بك بـ Heroku:**
    ```bash
    heroku git:remote -a your-app-name-here
    ```
5.  **نشر التطبيق:**
    ```bash
    git push heroku master
    ```
    سيقوم Heroku تلقائيًا بتثبيت المتطلبات وتشغيل التطبيق.
6.  **فتح التطبيق في المتصفح:**
    ```bash
    heroku open
    ```

### 2. النشر باستخدام Docker (للمستخدمين المتقدمين)

إذا كنت معتادًا على Docker، يمكنك بناء صورة Docker للتطبيق ونشرها على أي خدمة تدعم Docker (مثل Docker Hub, AWS ECS, Google Kubernetes Engine).

**المتطلبات:**
- Docker مثبت على جهازك.

**الخطوات:**
1.  **بناء صورة Docker:**
    ```bash
    cd /path/to/your/project/folder
    docker build -t hospital-fire-safety .
    ```
2.  **تشغيل التطبيق محليًا (للاختبار):**
    ```bash
    docker run -p 5000:5000 hospital-fire-safety
    ```
    يمكنك الآن الوصول إلى التطبيق عبر `http://localhost:5000`.
3.  **نشر الصورة إلى سجل Docker (اختياري):**
    ```bash
    docker tag hospital-fire-safety your-docker-username/hospital-fire-safety
    docker push your-docker-username/hospital-fire-safety
    ```
4.  **النشر على خدمة سحابية:** اتبع تعليمات مزود الخدمة السحابية لنشر صورة Docker الخاصة بك.

### 3. النشر على Google App Engine (GAE)

Google App Engine هي منصة لإنشاء تطبيقات الويب وتشغيلها على بنية Google التحتية.

**المتطلبات:**
- حساب Google Cloud Platform.
- Google Cloud SDK مثبت على جهازك.

**الخطوات:**
1.  **تسجيل الدخول إلى Google Cloud:**
    ```bash
    gcloud auth login
    ```
2.  **تهيئة مشروع Google Cloud:**
    ```bash
    gcloud init
    ```
3.  **نشر التطبيق:**
    ```bash
    cd /path/to/your/project/folder
    gcloud app deploy
    ```
    سيقوم GAE تلقائيًا بنشر التطبيق الخاص بك.

## 🔑 بيانات تسجيل الدخول الافتراضية

بعد النشر، يمكنك تسجيل الدخول باستخدام البيانات التالية:

-   **البريد الإلكتروني:** `alisallwe22@gmail.com`
-   **كلمة المرور:** `admin123`

## ⚠️ ملاحظات هامة

-   **الأمان:** تأكد من تغيير `SECRET_KEY` في ملف `src/main.py` إلى قيمة عشوائية قوية قبل النشر في بيئة الإنتاج.
-   **قاعدة البيانات:** يستخدم التطبيق SQLite بشكل افتراضي، وهو مناسب للتطوير والاختبار. للنشر في بيئة الإنتاج، يفضل استخدام قاعدة بيانات أكثر قوة مثل PostgreSQL أو MySQL.
-   **المتطلبات:** تأكد من أن ملف `requirements.txt` يحتوي على جميع المكتبات اللازمة لتشغيل التطبيق.

نتمنى لك نشرًا ناجحًا! إذا واجهت أي مشاكل، يرجى الرجوع إلى وثائق المنصة التي اخترتها للنشر.

